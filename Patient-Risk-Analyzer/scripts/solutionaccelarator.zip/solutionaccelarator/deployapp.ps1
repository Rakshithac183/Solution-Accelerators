﻿# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
Start-Transcript -Path C:\WindowsAzure\Logs\CloudLabsCustomScriptExtension.txt -Append
[Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls
[Net.ServicePointManager]::SecurityProtocol = "tls12, tls11, tls" 

$ShowDisclaimer = "Y"
$AgreementAnswer = ShowDisclaimer

while (!($AgreementAnswer).ToUpper().Equals("Y")) {
    if (($AgreementAnswer).ToUpper().Equals("N")) {
        exit 0
    }
    $AgreementAnswer = ShowDisclaimer
}

#login azure
Write-Host "Login to Azure"
az Login -u "enter_user_name" -p "enter_password"

$subscriptionId = "enter_sub_id"
$resourcegroupName = "enter_rg_name"
$containerRegistryName = "enter_container_registy_name"
$kubernetesName = "enter_kunernetes_name"
$azurecosmosaccountName = "enter_cosmosdb_name"
$azurecosmosdbDataBaseName = "patienthubdb"
$ttsSubscriptionKey = "enter_speech_sub_key"
$ttsServiceRegion =  "enter_speech_region"
$mlServiceURL = "enter_ml_service_url"
$mlServiceBearerToken =  "enter_ml_bearertoken"

az account set --subscription $subscriptionId

$resourceGroup = az group exists -n $resourcegroupName
if ($resourceGroup -eq $false) {
    throw "The Resource group '$resourcegroupName' is not exist`r`n Please check resource name and try it again"
}

Write-Host "Step 1 - Setup Azure Container Registry"

az acr update --name $containerRegistryName --admin-enabled true

Write-Host "..... Retrieving Configuration Setting in Container Registry"

$acrList = az acr list | Where-Object { $_ -match $containerRegistryName + ".*" }
$loginServer = $acrList[1].Split(":")[1].Replace('"', '').Replace(',', '').Replace(' ', '')
$registryName = $acrList[2].Split(":")[1].Replace('"', '').Replace(',', '').Replace(' ', '')

$userName = $registryName
$password = ( az acr credential show --name $userName | ConvertFrom-Json).passwords.value.Split(" ")[1] 

Write-Host "..... loginServer: '$loginServer'"
Write-Host "..... registryName: '$registryName'"
Write-Host "..... userName: '$userName'"
Write-Host "..... userPassword: '$password'"

Write-Host "Step 2 - Setup Azure Kubernetes Service and Azure Container Service"

az aks update -n $kubernetesName -g $resourcegroupName --attach-acr $containerRegistryName

Write-Host "Step3 - Update Azure CosmosDB ConnectionString in App configuration...."

$connectionString = az cosmosdb keys list `
    --type connection-strings `
    --name $azurecosmosaccountName `
    --resource-group $resourcegroupName `
    --query "connectionStrings[?contains(description, 'Primary SQL Connection String')].[connectionString]" -o tsv

#Replace connectionstring in each appsettings.json files
#
# AppointmentService
#
((Get-Content -path src\Microsoft.Solutions.PatientHub.AppointmentService.Host\appsettings.json.template -Raw) -replace '{DBConnectionString}', $connectionString) | Set-Content -Path src\Microsoft.Solutions.PatientHub.AppointmentService.Host\appsettings.json
((Get-Content -path src\Microsoft.Solutions.PatientHub.AppointmentService.Host\appsettings.json -Raw) -replace '{DatabaseName}', $azurecosmosdbDataBaseName) | Set-Content -Path src\Microsoft.Solutions.PatientHub.AppointmentService.Host\appsettings.json

#
# BatchInferenceService
#
((Get-Content -path src\Microsoft.Solutions.PatientHub.BatchInferenceService.Host\appsettings.json.template -Raw) -replace '{DBConnectionString}', $connectionString) | Set-Content -Path src\Microsoft.Solutions.PatientHub.BatchInferenceService.Host\appsettings.json
((Get-Content -path src\Microsoft.Solutions.PatientHub.BatchInferenceService.Host\appsettings.json -Raw) -replace '{DatabaseName}', $azurecosmosdbDataBaseName) | Set-Content -Path src\Microsoft.Solutions.PatientHub.BatchInferenceService.Host\appsettings.json

#
# CognitiveService
#
((Get-Content -path src\Microsoft.Solutions.PatientHub.CognitiveService.Host\appsettings.json.template -Raw) -replace '{DBConnectionString}', $connectionString) | Set-Content -Path src\Microsoft.Solutions.PatientHub.CognitiveService.Host\appsettings.json
((Get-Content -path src\Microsoft.Solutions.PatientHub.CognitiveService.Host\appsettings.json -Raw) -replace '{DatabaseName}', $azurecosmosdbDataBaseName) | Set-Content -Path src\Microsoft.Solutions.PatientHub.CognitiveService.Host\appsettings.json
((Get-Content -path src\Microsoft.Solutions.PatientHub.CognitiveService.Host\appsettings.json -Raw) -replace '{TTSSubscriptionKey}', $ttsSubscriptionKey) | Set-Content -Path src\Microsoft.Solutions.PatientHub.CognitiveService.Host\appsettings.json
((Get-Content -path src\Microsoft.Solutions.PatientHub.CognitiveService.Host\appsettings.json -Raw) -replace '{TTSServiceRegion}', $ttsServiceRegion) | Set-Content -Path src\Microsoft.Solutions.PatientHub.CognitiveService.Host\appsettings.json

#
# PatientService
#
((Get-Content -path src\Microsoft.Solutions.PatientHub.PatientService.Host\appsettings.json.template -Raw) -replace '{DBConnectionString}', $connectionString) | Set-Content -Path src\Microsoft.Solutions.PatientHub.PatientService.Host\appsettings.json
((Get-Content -path src\Microsoft.Solutions.PatientHub.PatientService.Host\appsettings.json -Raw) -replace '{DatabaseName}', $azurecosmosdbDataBaseName) | Set-Content -Path src\Microsoft.Solutions.PatientHub.PatientService.Host\appsettings.json

#
# RealtimeInferenceService
#
((Get-Content -path src\Microsoft.Solutions.PatientHub.RealtimeInferenceService.Host\appsettings.json.template -Raw) -replace '{DBConnectionString}', $connectionString) | Set-Content -Path src\Microsoft.Solutions.PatientHub.RealtimeInferenceService.Host\appsettings.json
((Get-Content -path src\Microsoft.Solutions.PatientHub.RealtimeInferenceService.Host\appsettings.json -Raw) -replace '{DatabaseName}', $azurecosmosdbDataBaseName) | Set-Content -Path src\Microsoft.Solutions.PatientHub.RealtimeInferenceService.Host\appsettings.json
((Get-Content -path src\Microsoft.Solutions.PatientHub.RealtimeInferenceService.Host\appsettings.json -Raw) -replace '{MLserviceUrl}', $mlServiceURL) | Set-Content -Path src\Microsoft.Solutions.PatientHub.RealtimeInferenceService.Host\appsettings.json
((Get-Content -path src\Microsoft.Solutions.PatientHub.RealtimeInferenceService.Host\appsettings.json -Raw) -replace '{MLServiceBearerToken}', $MLServiceBearerToken) | Set-Content -Path src\Microsoft.Solutions.PatientHub.RealtimeInferenceService.Host\appsettings.json

#
# ChangeFeedWatcherService
#
((Get-Content -path src\Microsoft.Solutions.PatientHub.BatchInference.ChangefeedWatcherWorker\appsettings.json.template -Raw) -replace '{DBConnectionString}', $connectionString) | Set-Content -Path src\Microsoft.Solutions.PatientHub.BatchInference.ChangefeedWatcherWorker\appsettings.json
((Get-Content -path src\Microsoft.Solutions.PatientHub.BatchInference.ChangefeedWatcherWorker\appsettings.json -Raw) -replace '{DatabaseName}', $azurecosmosdbDataBaseName) | Set-Content -Path src\Microsoft.Solutions.PatientHub.BatchInference.ChangefeedWatcherWorker\appsettings.json


Write-Host "Step 4 - Build Container and push Azure container registry...."

#Build and Containerizing then Push to Azure Container Registry
 Set-location ".\src"

docker build -f .\Microsoft.Solutions.PatientHub.AppointmentService.Host\Dockerfile --rm -t 'patienthub/appointment' .
docker build -f .\Microsoft.Solutions.PatientHub.BatchInferenceService.Host\Dockerfile --rm -t 'patienthub/batchinference' .
docker build -f .\Microsoft.Solutions.PatientHub.BatchInference.ChangefeedWatcherWorker\Dockerfile --rm -t 'patienthub/changefeedwatcher' .
docker build -f .\Microsoft.Solutions.PatientHub.CognitiveService.Host\Dockerfile --rm -t 'patienthub/tts' .
docker build -f .\Microsoft.Solutions.PatientHub.PatientService.Host\Dockerfile --rm -t 'patienthub/patient' .
docker build -f .\Microsoft.Solutions.PatientHub.RealtimeInferenceService.Host\Dockerfile --rm -t 'patienthub/realtimeinference' .

docker tag 'patienthub/appointment' "$containerRegistryName.azurecr.io/patienthub/appointment"
docker tag 'patienthub/batchinference' "$containerRegistryName.azurecr.io/patienthub/batchinference"
docker tag 'patienthub/changefeedwatcher' "$containerRegistryName.azurecr.io/patienthub/changefeedwatcher"
docker tag 'patienthub/tts' "$containerRegistryName.azurecr.io/patienthub/tts"
docker tag 'patienthub/patient' "$containerRegistryName.azurecr.io/patienthub/patient"
docker tag 'patienthub/realtimeinference' "$containerRegistryName.azurecr.io/patienthub/realtimeinference"

Write-Host "Login to ACS `r`n"
docker login "$containerRegistryName.azurecr.io" -u $userName -p $password

Write-Host "Push Images to ACS`r`n"
docker push "$containerRegistryName.azurecr.io/patienthub/appointment"
docker push "$containerRegistryName.azurecr.io/patienthub/batchinference"
docker push "$containerRegistryName.azurecr.io/patienthub/changefeedwatcher"
docker push "$containerRegistryName.azurecr.io/patienthub/tts"
docker push "$containerRegistryName.azurecr.io/patienthub/patient"
docker push "$containerRegistryName.azurecr.io/patienthub/realtimeinference"

Set-Location ..

Write-Host "Step 5 - Set up AKS and Deploy Applications from Azure Container Registry...."
# # Set Kubernets context
az aks get-credentials -g $resourceGroupName -n $kubernetesName

Write-Host "Preparing Kubernetes Deployment.....`r`n"
# #Set up Deployment yaml file to deploy APIs
((Get-Content -path manifests\kubernetes-deployment.yaml.template -Raw) -replace '{acrname}', $containerRegistryName) | Set-Content -Path manifests\kubernetes-deployment.yaml

Write-Host "Deploy Services from ACR to Kubernetes.....`r`n"
kubectl create ns patienthub
# #Deploy Containers to Kubernetes
kubectl apply -f manifests\kubernetes-deployment.yaml --namespace patienthub

Write-Host "Application deployment has been finished.....`r`n"

Write-Host "Check the IP Address for each services`r`n"
kubectl get service -o=custom-columns=NAME:.metadata.name,EXTERNAL_IP:.status.loadBalancer.ingress[0].ip,PORT:.spec.ports[0].targetPort -n patienthub 
